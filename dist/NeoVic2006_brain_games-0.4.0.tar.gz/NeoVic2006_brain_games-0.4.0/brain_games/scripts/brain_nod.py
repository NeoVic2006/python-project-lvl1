from brain_games.games.nod_algorithm import nod_calculation


def main():
    nod_calculation()


if __name__ == '__main__':
    main()
