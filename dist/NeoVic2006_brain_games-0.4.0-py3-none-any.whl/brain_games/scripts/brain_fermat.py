from brain_games.games.fermat_algorithm import fermat_alg


def main():
    fermat_alg()


if __name__ == '__main__':
    main()