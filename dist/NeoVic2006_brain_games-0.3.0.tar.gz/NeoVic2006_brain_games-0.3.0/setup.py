# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain-calc:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-nod = brain_games.scripts.brain_nod:main',
                     'brain-prog = brain_games.scripts.brain_prog:main']}

setup_kwargs = {
    'name': 'neovic2006-brain-games',
    'version': '0.3.0',
    'description': 'Updated with Progression game',
    'long_description': None,
    'author': 'Sergey Vengilevskiy',
    'author_email': 'NeoVic2006@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
