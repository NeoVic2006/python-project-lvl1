from brain_games.games.game_calculcator import calculator


def main():
    calculator()


if __name__ == '__main__':
    main()
